Pxmin=0; % X min of profile
Pxmax=800; % X max of profile
Pstep=10; % Steps in X profile

Dzmin=0; % Z min Depth (Top of plate)
Dzmax=40; % Z max Depth (Max Elastic Thickness)

sx=length(Pxmin:Pstep:Pxmax); % compute length of the vector
sd=((Dzmax-Dzmin))/(sx-1); %compute step for the depths vectores

LOADS_MATRIX=[ [Pxmin:Pstep:Pxmax]' zeros(sx,1) [Pxmin:Pstep:Pxmax]' zeros(sx,1) [Dzmin:sd:Dzmax]' zeros(sx,1) [Dzmin:sd:Dzmax]' zeros(sx,1)]; % Create the empty loads matrix

dlmwrite('loads.txt','%x_top	h_top	x_bot	f_bot	z_right	f_right	z_left	f_left','')
dlmwrite('loads.txt',LOADS_MATRIX,'delimiter','\t','-append') % Write Loads matrix to file

