
L=300000; % long in m of the plate
H=25000; % high in m of the plate (Elastic Thickness)
GradT=0.025; %Geothermal gradient in C/m

pv=[L 0  ;   0 0;... %Top of the plate
    0 H; 25000 H; 50000 H; 75000 H ; 100000 H/2 ;125000 H/2 ; 150000 H/2 ; 175000 H/2 ; 200000 H/3 ; 225000 H/3 ; 250000 H/3 ; 275000 H/4 ;   L H/4;... %elastic thickness along the plate
    L 0 ] %close the polygon
[p,TC]=distmesh2d(@dpoly,@huniform,2500,[min(pv(:,1)),min(pv(:,2)); max(pv(:,1)),max(pv(:,2))],pv,pv);
set(gca,'Ydir','reverse')

vXnodes=p(:,1);
vZnodes=p(:,2);
TZ0=vZnodes*GradT;