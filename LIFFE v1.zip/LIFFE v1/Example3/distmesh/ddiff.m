function d=ddiff(d1,d2), d=max(d1,-d2);

%   Copyright (C) 2004-2012 Per-Olof Persson. See COPYRIGHT.TXT for details.
