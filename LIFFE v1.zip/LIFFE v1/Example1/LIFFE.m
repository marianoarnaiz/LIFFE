% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %                                             %
% %                LIFFE v1.0                   %
% %   LIthopheric Flexure w/ Finite Elementes   %
% %       Arnaiz-Rodriguez et al. (2018)        %
% %                                             %
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Welcome to LIFFE v1.0 a finite elements package desing to model
% lithospheric flexure. This series of function are mainly based on the
% equations presented by Chandrupatla & Belegundu (2012) and Watts (2001).
%
% LIFFE is made up of a couple of directories:
%
% bin: Contains all the functions that were created by the author and some
%      colormaps (Rudis, Ross and Garnier, 2018). 
%      Type help and the name of each funtion to get some information
%      on it. 
%
% distmesh: Contains the distmesh package by Per-Olof Persson (2004-2012)
%           that is used to create the finite element mesh.
%
% Besides them LIFFE uses this master file to call the functions and run
% the computations in proper order and uses two input files:
%
% loads.txt: Contains the information of the loads applied at the top,
%            bottom, right and left sides of the plate. The file has
%            this format:
%        x_top	h_top	x_bot	f_bot	z_right	f_right	z_left	f_left
% 
%        x_? and z_? represent the position of the load, h_top is for
%        topography heigh and f_? is the magnitud of the load  
%        Some conventions: 
%                         h_top= heigh of topography
%                         fbot= negative is upward force
%                         f_left= negative is extension to the left
%                         f_right= negative is compression
%
% DATA.txt: Contains the observed topography and gravity anomalies. The
%           file has this format:
%           Distantes Topography FAA BA
%
% To run LIFFE just press RUN on this file!
% Have fun using it to model the deformation of the lithosphere!
%

%% Clean Up and Begin!
tic %keep track of run time
clc; close all; clearvars; format long g; warning off
cd bin; path_bin=pwd; cd .. %add bin to path
addpath(path_bin); %add bin to path
cd distmesh; path_distmesh=pwd; cd .. %add distmesh to path
addpath(path_distmesh); %add distmesh to path
disp('You are running LIFFE v1.0, HAVE FUN :)')
disp(' ')
disp('RUNNING: EXAMPLE 1')
disp(' ')
%% Define PARAMETRES of the FLEXURE

%MOHO DEPTH
MOHO=10000; %Thickness of the undeformed crust (only used for gravity anomalies)

%BASE LINE
BASEL=-5000; %Base line of the flexure is the Position of the flexure in meters with respect to the mean sea level
WATER=1; %WATER 1=yes 0=no. The displace material is water if this value es 1 and air if it is 0;

% Mechanical Parameters of the elements
v=0.25; % Poisson's Ratio
E=70e9; % Young's Moduli [Pa]
muk=0.7; %Coefficient of Kinetic Friction (only needed for some restrictions)

% Densities
rhoC=2850; % Density of the crust [kg/m^3]
rhoL=2800; % Density of mountain loads [kg/m^3]
rhoM=3200; % Density of Mantle [kg/m^3]
rhoS=2600; % Density of Sedimentes in the Basin [kg/m^3]
rhoW=1030; % Density of Water [kg/m^3]

%Consider that the flexure is in water accordingly with Watts (2001)
if WATER==1
    %rhoC=rhoC-rhoW;
    %rhoL=rhoL-rhoW;
    disp('Flexure is in water')
else
    disp('Flexure is in land')
end
    
%Fill index: this index is the porcentage of fill on the formed depression
%where 0 is no filling (totally hungry basin) and 1 is fully filled
fillindex=1;

% Thermal Parameters
T0=25; %Temperature at 0 in the model [C]
GradT=0.025; %Geothermal gradient [C/m]
alfa = 3.1e-5; % Coefficient of thermal expansion [C^-1]
AtmGratT=-0.0065; %Troposphere thermal gradient [C/m]

% Gravity aceleration
grav=9.81; % Gravity Aceleration [m/s^2]

disp('Reading PLATE Parameters')
%%  Define PARAMETERS of the ELEMTENTS AND PLATE

te=1; % Elements thicknes in Y direction [m]
L=300000; % long in m of the plate [m]
H=25000; % high in m of the plate (Elastic Thickness) [m]
sizem=2500; % ELEMENTS SIZE [m?]
R=[2 0]; % RESTRICTION ACORDING TO FUNCTION "RESTRICTIONS"

% R=0 NO Restrictions
% R=1 Horizontal displacement restricted
% R=2 Horizontal and Vertical displacement restricted
% R=3 Horizontal displacement damped according tu crustal density
% R=4 Horizontal displacement damped according tu crustasl density and
%     and Vertical displament reduced by friction according to muk variable

disp('Reading ELEMENTS & PLATE Parameters')
disp(' ')
%% READING LOADS and DATA FILES

load loads.txt %read the loads file
load DATA.txt %read observed information file (Distance (km) Topography (m) FAA (mGal) BA (mGal))

%% TE VARIATIONS

TOP=[L 0; 275000 0; 190000 0; 180000 0; 130000 0 ; 120000 0 ; 110000 0; 25000 0; 0 0]; %shape of the top of the plate (Stands for previous deformation on the top before the flexure)
BOTTOM=[0 H;  25000 H; 50000 H; 75000 H ; 100000 H ;125000 H ; 150000 H ; 175000 H ; 200000 H ; 225000 H ; 250000 H ; 275000 H ;   L H]; %shape of the bottom of the plate (stands of Elastic Thickness Variations)

pv=[TOP; BOTTOM; L 0]; % close polygon 
%% SET THE INITIAL PROBLEM IN FINITE ELEMTENS

[vXnodes,vZnodes,vNodesNames,nodesontop,nodesonbottom,nodesonleft,nodesonright,NUMBER_OF_ELEMENTS,TC,TZ0] = MAKEdistmeshNODES(L,TOP,BOTTOM, pv,sizem,GradT,T0);
[D,TC,B,Ke,K,Knr] = FEMmatrixes(TC,vXnodes,vZnodes,vNodesNames,E,v,te); %Setting stiffness;

%% SET THE LOADS

[F,xload,zload_ontop,TopoLOAD] = AddLoads(loads,vNodesNames,vXnodes,vZnodes,nodesontop,nodesonbottom,nodesonleft,nodesonright,rhoL,rhoW,grav,te,WATER); %consider loads from loads file 

%% SET RESTRICTIONS

[K,W,F]= Restrictions(F,R,vXnodes,vZnodes,nodesontop,nodesonbottom,nodesonleft,nodesonright,K,rhoM,rhoC,grav,te,muk); % set restrictions accoding to R parameter and mantle density

%% STRAIN BY LOADING

[vQ1,vXnodes_Q1,vZnodes_Q1] = STRAIN(K,F,vXnodes,vZnodes); %Compute the strain produced by the information in loads file

%% CONSIDER SEDIMENTARY LOAD

[FpS] = Sload(vXnodes_Q1,vZnodes_Q1,xload,zload_ontop,vNodesNames,nodesontop,fillindex,rhoS,grav,te); %Forces due to sedimentary load 
[D,TC_2,B_2,Ke_2,K_2,Knr_2] = FEMmatrixes(TC,vXnodes_Q1,vZnodes_Q1,vNodesNames,E,v,te); %Setting stiffness for the new nodemal positions;
[K_2,W,FpS]= Restrictions(FpS,R,vXnodes,vZnodes,nodesontop,nodesonbottom,nodesonleft,nodesonright,K_2,rhoM,rhoC,grav,te,muk); % set restrictions accoding to R parameter and mantle density

%% STRAIN BY SEDIMENTS
[vQ2,vXnodes_Q2,vZnodes_Q2] = STRAIN(K_2,FpS,vXnodes_Q1,vZnodes_Q1); % Compute strain due to sedimentary load

%% COMPUTE STRESS DUE TO NONE THERMAL LOADS

[SIGMA,SIGMA_V] = doSigmas(TC,vXnodes_Q2,vXnodes,vZnodes_Q2,vZnodes,D,B); % Compute stress in X,Y and principal strees

%% CONSIDER TEMPERATURE EFFECT

[D,TC_3,B_3,Ke_3,K_3,Knr_3] = FEMmatrixes(TC_2,vXnodes_Q2,vZnodes_Q2,vNodesNames,E,v,te); %Setting stiffness for the new nodemal positions;
[FpT,Eo,TZf] = dTEMP(vZnodes_Q2,GradT,AtmGratT,vNodesNames,TC_3,B_3,alfa,D,TZ0,v,te,T0); % Compute nodal loads due to temperature change in a force vector
[vQ3,vXnodes_Q3,vZnodes_Q3] = STRAIN(K_2,FpT,vXnodes_Q2,vZnodes_Q2); % Compute strain due to thermal load
[SIGMA_T,SIGMA_V_T] = doSigmasT(TC_3,vXnodes_Q3,vXnodes_Q2,vZnodes_Q3,vZnodes_Q2,D,B_3,Eo); % Compute stress in X,Y and principal strees

%% FINAL STRESS CONSIDERING DEFORMATION BY LOADS AND TEMPERATURE CHANGE

SIGMA_F=SIGMA+SIGMA_T;
SIGMA_V_F=SIGMA_V+SIGMA_V_T;

 %% PLOT SOME FIGURES :)
    
[AA,AB] = plotFIGURES(DATA,rhoC,rhoL,rhoM,rhoS,rhoW,MOHO,BOTTOM,TC,vXnodes,vZnodes,vXnodes_Q2,vZnodes_Q2,vXnodes_Q3,vZnodes_Q3,nodesontop,nodesonbottom,nodesonright,nodesonleft,xload,zload_ontop,TZ0,TZf,SIGMA_V,BASEL,WATER,fillindex);

%% FINE!
toc
disp('FINE!')
